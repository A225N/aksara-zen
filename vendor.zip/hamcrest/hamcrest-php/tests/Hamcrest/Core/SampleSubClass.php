<?php
namespace Hamcrest\Core;

class SampleSubClass extends \Hamcrest\Core\SampleBaseClass
{
}
